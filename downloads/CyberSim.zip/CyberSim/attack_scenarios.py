# attack_scenarios.py
import pandas as pd

# Exemple fictif de données de vulnérabilités
vulnerabilities = [
    {"cve_id": "CVE-2023-1234", "criticality": "high", "exploit_available": True},
    {"cve_id": "CVE-2023-5678", "criticality": "medium", "exploit_available": False},
    {"cve_id": "CVE-2022-7890", "criticality": "critical", "exploit_available": True}
]

# Fonction pour calculer la probabilité de succès d'une attaque en fonction des vulnérabilités
def calculate_attack_success(vulnerabilities):
    score = 0
    for vuln in vulnerabilities:
        if vuln['criticality'] == "critical" and vuln['exploit_available']:
            score += 70  # Très élevé
        elif vuln['criticality'] == "high" and vuln['exploit_available']:
            score += 50  # Élevé
        elif vuln['criticality'] == "medium":
            score += 30  # Moyen
        else:
            score += 10  # Faible

    # Calcul d'une probabilité en fonction du score global
    success_rate = min(score, 100)  # On limite à 100%
    return success_rate

def simulate_attack(scenario):
    if scenario == "phishing":
        return phishing_attack()
    elif scenario == "ransomware":
        return ransomware_attack()
    elif scenario == "ddos":
        return ddos_attack()
    else:
        return "Scénario non reconnu."

def phishing_attack():
    # Simule une attaque de phishing basée sur des métriques réalistes
    success_rate = calculate_attack_success(vulnerabilities)
    return {
        "type": "Phishing",
        "success": success_rate > 50,  # Disons que si la probabilité est > 50%, l'attaque réussit
        "message": f"Phishing réussi avec une probabilité de succès de {success_rate}%"
    }

def ransomware_attack():
    # Simule une attaque par ransomware basée sur des données de vulnérabilité
    success_rate = calculate_attack_success(vulnerabilities)
    return {
        "type": "Ransomware",
        "success": success_rate > 60,
        "message": f"Ransomware activé avec une probabilité de succès de {success_rate}%"
    }

def ddos_attack():
    # Simule une attaque DDoS
    success_rate = calculate_attack_success(vulnerabilities)
    return {
        "type": "DDoS",
        "success": success_rate > 40,
        "message": f"Le serveur est tombé avec une probabilité de succès de {success_rate}%"
    }
