import pandas as pd

def generate_report(results):
    # Crée un rapport sous forme de DataFrame
    report_data = {
        "Type d'attaque": results['type'],
        "Statut": results['message']
    }
    report_df = pd.DataFrame([report_data])
    report_df.to_csv('attack_report.csv', index=False)
    return "Rapport généré avec succès."
